# Match - New Zealand NHI IG v1.6.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Match**

## Example Parameters: Match



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Match",
  "parameter" : [
    {
      "extension" : [
        {
          "url" : "http://hl7.org.nz/fhir/StructureDefinition/nz-ethnicity",
          "valueCodeableConcept" : {
            "coding" : [
              {
                "system" : "https://standards.digital.health.nz/ns/ethnic-group-level-4-code",
                "version" : "2.0",
                "code" : "21111",
                "display" : "Māori"
              }
            ],
            "text" : "Māori"
          }
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org.nz/fhir/StructureDefinition/birth-place#country",
              "valueCodeableConcept" : {
                "coding" : [
                  {
                    "system" : "urn:iso:std:iso:3166",
                    "version" : "2013",
                    "code" : "AU",
                    "display" : "Australia"
                  }
                ],
                "text" : "Australia"
              }
            },
            {
              "url" : "http://hl7.org.nz/fhir/StructureDefinition/birth-place#placeofbirth",
              "valueString" : "Sydney"
            }
          ],
          "url" : "http://hl7.org.nz/fhir/StructureDefinition/birth-place"
        }
      ],
      "name" : "resource",
      "resource" : {
        "resourceType" : "Patient",
        "meta" : {
          "versionId" : "123"
        },
        "name" : [
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-preferred",
                "valueBoolean" : true
              }
            ],
            "use" : "nickname",
            "text" : "TEST-AQURE, ROBERT",
            "family" : "TEST-AQURE",
            "given" : ["ROBERT"]
          }
        ],
        "gender" : "male",
        "birthDate" : "1985-06-15",
        "address" : [
          {
            "use" : "home",
            "type" : "physical",
            "line" : ["24 Warren Avenue", "Three Kings"],
            "district" : "Auckland 1042"
          }
        ]
      }
    },
    {
      "name" : "count",
      "valueInteger" : 10
    },
    {
      "name" : "onlyCertainMatches",
      "valueBoolean" : false
    }
  ]
}

```
