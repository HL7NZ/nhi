# Naming Systems - New Zealand NHI IG v1.6.5

* [**Table of Contents**](toc.md)
* **Naming Systems**

## Naming Systems

### Identifiers

These are identifiers defined in this IG. They are defined using
[NamingSystem](http://hl7.org/fhir/namingsystem.html)resources.

* Description: NHI number
  * Url: https://standards.digital.health.nz/ns/nhi-id
  * Other identifiers: * https://standards.digital.health.nz/id/nhi (uri) Deprecated
* 2.16.840.1.113883.2.18.2 (oid) 

  * Responsible: HISO

