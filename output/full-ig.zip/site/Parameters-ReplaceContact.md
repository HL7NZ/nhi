# ReplaceContact - New Zealand NHI IG v1.6.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ReplaceContact**

## Example Parameters: ReplaceContact



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "ReplaceContact",
  "parameter" : [
    {
      "name" : "nhi",
      "valueString" : "ZKC4633"
    },
    {
      "name" : "version-id",
      "valueString" : "23456"
    },
    {
      "name" : "contact-id",
      "valueString" : "3"
    },
    {
      "name" : "use",
      "valueString" : "home"
    },
    {
      "name" : "system",
      "valueString" : "email"
    },
    {
      "name" : "value",
      "valueString" : "test2.contact@testContact.com"
    },
    {
      "name" : "isVerified",
      "valueBoolean" : true
    },
    {
      "name" : "isShared",
      "valueBoolean" : false
    },
    {
      "name" : "isPrivate",
      "valueBoolean" : true
    },
    {
      "name" : "context",
      "valueString" : "between 9am and 6pm only"
    }
  ]
}

```
