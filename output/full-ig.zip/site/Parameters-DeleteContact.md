# DeleteContact - New Zealand NHI IG v1.7.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DeleteContact**

## Example Parameters: DeleteContact



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "DeleteContact",
  "parameter" : [{
    "name" : "nhi",
    "valueString" : "ZKC4633"
  },
  {
    "name" : "version-id",
    "valueString" : "12345"
  },
  {
    "name" : "contact-id",
    "valueString" : "3"
  }]
}

```
