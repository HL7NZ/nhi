# Replace a contact on a patient's NHI record. - New Zealand NHI IG v1.6.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Replace a contact on a patient's NHI record.**

## OperationDefinition: Replace a contact on a patient's NHI record. 

| | |
| :--- | :--- |
| *Official URL*:https://nhi-ig.hip.digital.health.nz/OperationDefinition/replace-contact | *Version*:1.6.5 |
| Draft as of 2023-06-12 | *Computable Name*:Replace Contact |

 
An operation to replace a contact on a patient's NHI record 

URL: [base]/Patient/[id]/$replace-contact

### Parameters

* **Use**: IN
  * **Name**: nhi
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: The Patient's nhi number
* **Use**: IN
  * **Name**: version-id
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: The current value of the patient resources meta.versionId
* **Use**: IN
  * **Name**: contact-id
  * **Scope**: 
  * **Cardinality**: 1..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: The id of the contact to be replaced
* **Use**: IN
  * **Name**: use
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: home or mobile
* **Use**: IN
  * **Name**: system
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: phone or email
* **Use**: IN
  * **Name**: value
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: the phone number or email address
* **Use**: IN
  * **Name**: isVerified
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: Verification has been performed to determine that the email or phone number can be used to communicate with the patient (true or false)
* **Use**: IN
  * **Name**: isShared
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: The email address or phone number is shared with other people (true or false)
* **Use**: IN
  * **Name**: isPrivate
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: The email address or phone number may be used to communicate private health information about the individual identified by the NHI
* **Use**: IN
  * **Name**: context
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [string](http://hl7.org/fhir/R4/datatypes.html#string)
  * **Binding**: 
  * **Documentation**: Additional information about the context of use of this contact
* **Use**: OUT
  * **Name**: return
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [Patient](http://hl7.org/fhir/R4/patient.html)
  * **Binding**: 
  * **Documentation**: The updated patient resource
* **Use**: OUT
  * **Name**: failure
  * **Scope**: 
  * **Cardinality**: 0..1
  * **Type**: [OperationOutcome](http://hl7.org/fhir/R4/operationoutcome.html)
  * **Binding**: 
  * **Documentation**: Error response

The NHI is validated, the versionId is validated, the parameters validated. If all request parameters are valid the new contact is added to the nhi record.



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "Patient-replace-contact",
  "url" : "https://nhi-ig.hip.digital.health.nz/OperationDefinition/replace-contact",
  "version" : "1.6.5",
  "name" : "Replace Contact",
  "title" : "Replace a contact on a patient's NHI record.",
  "status" : "draft",
  "kind" : "operation",
  "experimental" : false,
  "date" : "2023-06-12T12:47:40+10:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "An operation to replace a contact on a patient's NHI record",
  "affectsState" : true,
  "code" : "replace-contact",
  "comment" : "The NHI is validated, the versionId is validated, the parameters validated. If all request parameters are valid the new contact is added to the nhi record.",
  "resource" : ["Patient"],
  "system" : false,
  "type" : false,
  "instance" : true,
  "parameter" : [
    {
      "name" : "nhi",
      "use" : "in",
      "min" : 1,
      "max" : "1",
      "documentation" : "The Patient's nhi number",
      "type" : "string"
    },
    {
      "name" : "version-id",
      "use" : "in",
      "min" : 1,
      "max" : "1",
      "documentation" : "The current value of the patient resources meta.versionId",
      "type" : "string"
    },
    {
      "name" : "contact-id",
      "use" : "in",
      "min" : 1,
      "max" : "1",
      "documentation" : "The id of the contact to be replaced",
      "type" : "string"
    },
    {
      "name" : "use",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "home or mobile",
      "type" : "string"
    },
    {
      "name" : "system",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "phone or email",
      "type" : "string"
    },
    {
      "name" : "value",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "the phone number or email address",
      "type" : "string"
    },
    {
      "name" : "isVerified",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "Verification has  been performed to determine that the email or phone number can be used to communicate with the patient (true or false)",
      "type" : "string"
    },
    {
      "name" : "isShared",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "The email address or phone number is shared with other people (true or false)",
      "type" : "string"
    },
    {
      "name" : "isPrivate",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "The email address or phone number may be used to communicate private health information about the individual identified by the NHI",
      "type" : "string"
    },
    {
      "name" : "context",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "Additional information about the context of use of this contact",
      "type" : "string"
    },
    {
      "name" : "return",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "documentation" : "The updated patient resource",
      "type" : "Patient"
    },
    {
      "name" : "failure",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "documentation" : "Error response",
      "type" : "OperationOutcome"
    }
  ]
}

```
