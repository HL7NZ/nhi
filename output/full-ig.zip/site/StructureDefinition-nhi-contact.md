# NHI Contact - New Zealand NHI IG v1.6.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NHI Contact**

## Extension: NHI Contact 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/nhi-contact | *Version*:1.6.5 |
| Active as of 2025-10-20 | *Computable Name*:NhiContact |

Additional attributes for managing patient contact information

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [NHI Patient](StructureDefinition-NhiPatient.md)
* Examples for this Extension: [Patient/ZKC4633](Patient-ZKC4633.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nhi|current/StructureDefinition/nhi-contact)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-nhi-contact.csv), [Excel](StructureDefinition-nhi-contact.xlsx), [Schematron](StructureDefinition-nhi-contact.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "nhi-contact",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/nhi-contact",
  "version" : "1.6.5",
  "name" : "NhiContact",
  "title" : "NHI Contact",
  "status" : "active",
  "date" : "2025-10-20T21:26:59+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "Additional attributes for managing patient contact information",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    }
  ],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [
    {
      "type" : "element",
      "expression" : "Telecom"
    }
  ],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Extension",
        "path" : "Extension",
        "short" : "NHI Contact",
        "definition" : "Additional attributes for managing patient contact information"
      },
      {
        "id" : "Extension.extension:isValidFormat",
        "path" : "Extension.extension",
        "sliceName" : "isValidFormat",
        "short" : "The format of the email address or phone number is valid (true or  false)",
        "min" : 0,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:isValidFormat.extension",
        "path" : "Extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:isValidFormat.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "isValidFormat"
      },
      {
        "id" : "Extension.extension:isValidFormat.value[x]",
        "path" : "Extension.extension.value[x]",
        "type" : [
          {
            "code" : "boolean"
          }
        ]
      },
      {
        "id" : "Extension.extension:isValidDomain",
        "path" : "Extension.extension",
        "sliceName" : "isValidDomain",
        "short" : "The domain of the email address is valid (true or  false)",
        "min" : 0,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:isValidDomain.extension",
        "path" : "Extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:isValidDomain.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "isValidDomain"
      },
      {
        "id" : "Extension.extension:isValidDomain.value[x]",
        "path" : "Extension.extension.value[x]",
        "type" : [
          {
            "code" : "boolean"
          }
        ]
      },
      {
        "id" : "Extension.extension:isVerified",
        "path" : "Extension.extension",
        "sliceName" : "isVerified",
        "short" : "Verification has  been performed to determine that the email or phone number can be used to communicate with the patient (true or false)",
        "min" : 0,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:isVerified.extension",
        "path" : "Extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:isVerified.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "isVerified"
      },
      {
        "id" : "Extension.extension:isVerified.value[x]",
        "path" : "Extension.extension.value[x]",
        "type" : [
          {
            "code" : "boolean"
          }
        ]
      },
      {
        "id" : "Extension.extension:isShared",
        "path" : "Extension.extension",
        "sliceName" : "isShared",
        "short" : "The email address or phone number is shared with other people (true or false)",
        "min" : 0,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:isShared.extension",
        "path" : "Extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:isShared.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "isShared"
      },
      {
        "id" : "Extension.extension:isShared.value[x]",
        "path" : "Extension.extension.value[x]",
        "type" : [
          {
            "code" : "boolean"
          }
        ]
      },
      {
        "id" : "Extension.extension:isPrivate",
        "path" : "Extension.extension",
        "sliceName" : "isPrivate",
        "short" : "The email address or phone number may be used to communicate private health information about the individual identified by the NHI",
        "min" : 0,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:isPrivate.extension",
        "path" : "Extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:isPrivate.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "isPrivate"
      },
      {
        "id" : "Extension.extension:isPrivate.value[x]",
        "path" : "Extension.extension.value[x]",
        "type" : [
          {
            "code" : "boolean"
          }
        ]
      },
      {
        "id" : "Extension.extension:context",
        "path" : "Extension.extension",
        "sliceName" : "context",
        "short" : "Additional information about the context of use of this contact",
        "min" : 0,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:context.extension",
        "path" : "Extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:context.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "context"
      },
      {
        "id" : "Extension.extension:context.value[x]",
        "path" : "Extension.extension.value[x]",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Extension.url",
        "path" : "Extension.url",
        "fixedUri" : "http://hl7.org.nz/fhir/StructureDefinition/nhi-contact"
      },
      {
        "id" : "Extension.value[x]",
        "path" : "Extension.value[x]",
        "max" : "0"
      }
    ]
  }
}

```
