# Downloads - New Zealand NHI IG v1.6.5

* [**Table of Contents**](toc.md)
* **Downloads**

## Downloads

### Downloads

Download the conformance resources (StructureDefinition, ValueSet, CodeSystem). Formats available:

* [XML](definitions.xml.zip)
* [JSON](definitions.json.zip)
* [Turtle](definitions.ttl.zip)

Download the examples:

* [XML](examples.xml.zip)
* [JSON](examples.json.zip)
* [Turtle](examples.ttl.zip)

