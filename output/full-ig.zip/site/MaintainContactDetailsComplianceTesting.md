# Maintain Contact Details Compliance Testing - New Zealand NHI IG v1.7.0

* [**Table of Contents**](toc.md)
* **Maintain Contact Details Compliance Testing**

## Maintain Contact Details Compliance Testing

#### Maintain Contact Details Compliance Tests

 Use one of the agreed test NHI numbers for all tests unless stated otherwise. 
 For each successful update, retrieve the Patient record and confirm Patient.telecom reflects the change. 


* Reference: **Add-Contact-1**
  * Purpose – Demonstrate that the: application can add a home phone number
  * Input values: Use selected NHI. Add contact details: system = phone, use = home, valid phone number, optional verification/shared/private flags.
  * Expected outcome: Contact detail is added and returned in Patient.telecom.
  * Mandatory: Mandatory
* Reference: **Add-Contact-2**
  * Purpose – Demonstrate that the: application can add a mobile phone number
  * Input values: Use selected NHI. Add contact details: system = phone, use = mobile, valid mobile number.
  * Expected outcome: Contact detail is added and returned in Patient.telecom.
  * Mandatory: Mandatory
* Reference: **Add-Contact-3**
  * Purpose – Demonstrate that the: application can add an email address
  * Input values: Use selected NHI. Add contact details: system = email, use = null, valid email address.
  * Expected outcome: Contact detail is added and returned in Patient.telecom.
  * Mandatory: Mandatory
* Reference: **Add-Contact-4**
  * Purpose – Demonstrate that the: application can add contact details with optional metadata
  * Input values: Add valid contact detail with isVerified, isShared, isPrivate and context populated.
  * Expected outcome: Contact detail and supplied metadata are stored and displayed to the end user.
  * Mandatory: Mandatory
* Reference: **Replace-Contact-5**
  * Purpose – Demonstrate that the: application can replace an existing home phone value
  * Input values: Patient has active home phone. Replace same contact-id with same system/use and new valid phone value.
  * Expected outcome: Old contact detail is inactive; new value is active and returned.
  * Mandatory: Mandatory
* Reference: **Replace-Contact-6**
  * Purpose – Demonstrate that the: application can replace an existing mobile phone value
  * Input values: Patient has active mobile phone. Replace same contact-id with same system/use and new valid phone value.
  * Expected outcome: Old contact detail is inactive; new value is active and returned.
  * Mandatory: Mandatory
* Reference: **Replace-Contact-7**
  * Purpose – Demonstrate that the: application can replace an existing email value
  * Input values: Patient has active email. Replace same contact-id with system = email, use = null and new valid email value.
  * Expected outcome: Old email is inactive; new email is active and returned.
  * Mandatory: Mandatory
* Reference: **Replace-Contact-8**
  * Purpose – Demonstrate that the: application can replace contact context without changing system/use
  * Input values: Patient has active contact detail. Replace value and/or context while keeping system/use unchanged.
  * Expected outcome: Replacement succeeds and active contact details are returned.
  * Mandatory: Mandatory
* Reference: **Remove-Contact-9**
  * Purpose – Demonstrate that the: application can remove an active contact detail
  * Input values: Patient has active contact detail. Remove by valid contact-id.
  * Expected outcome: Contact detail is made inactive and is no longer returned in Patient.telecom.
  * Mandatory: Mandatory
* Reference: **Update-Contact-10**
  * Purpose – Demonstrate that the: application returns all active contact details after updates
  * Input values: Patient has home phone, mobile phone and email. Retrieve Patient record.
  * Expected outcome: Up to one email, one home phone and one mobile phone are returned.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-11**
  * Purpose – Demonstrate that the: contact details are returned only on Patient read
  * Input values: Patient has active contact details. Perform Patient read and Patient $match.
  * Expected outcome: Contact details are returned on read, not returned in $match.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-1**
  * Purpose – Demonstrate that the: application displays an error when patient version is not current
  * Input values: Two-user update scenario. User 1 retrieves version, User 2 updates contact details, User 1 submits stale version.
  * Expected outcome: EM02007 version number error.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-2**
  * Purpose – Demonstrate that the: application displays an error when NHI is dormant
  * Input values: Attempt add/replace/remove contact details for dormant NHI.
  * Expected outcome: EM02004 dormant NHI error.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-3**
  * Purpose – Demonstrate that the: application displays an error when mandatory fields are missing
  * Input values: Omit each mandatory field in turn: nhi, version-id, system, value; for replace/remove also omit contact-id.
  * Expected outcome: EM07201 missing required field, or contact-id error where applicable.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-4**
  * Purpose – Demonstrate that the: application displays an error when adding duplicate active system/use
  * Input values: Patient already has active home phone, mobile phone or email. Attempt to add another with same system/use.
  * Expected outcome: EM07222 already exists for this patient.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-5**
  * Purpose – Demonstrate that the: application displays an error when email has a use value
  * Input values: Add or replace with system = email and use = home or mobile.
  * Expected outcome: EM02403 email should not have a use.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-6**
  * Purpose – Demonstrate that the: application displays an error when phone has invalid or missing use
  * Input values: Add or replace with system = phone and use = null or invalid value.
  * Expected outcome: EM02404 phone must have use home or mobile.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-7**
  * Purpose – Demonstrate that the: application displays an error for invalid phone number
  * Input values: Add or replace phone with invalid phone value.
  * Expected outcome: EM02401 invalid phone number.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-8**
  * Purpose – Demonstrate that the: application displays an error for invalid email address
  * Input values: Add or replace email with invalid email value.
  * Expected outcome: EM02402 invalid email address.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-9**
  * Purpose – Demonstrate that the: application displays an error for invalid characters in value
  * Input values: Add or replace contact value containing invalid characters.
  * Expected outcome: EM07217 contains invalid text.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-10**
  * Purpose – Demonstrate that the: application displays an error for invalid characters in context
  * Input values: Add or replace contact details with invalid context text.
  * Expected outcome: EM02405 or EM07217 invalid context characters, depending on operation.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-11**
  * Purpose – Demonstrate that the: application displays an error when replacing with invalid/inactive contact-id
  * Input values: Replace using contact-id that is inactive, invalid, or not found.
  * Expected outcome: EM07107 contact ID invalid or inactive.
* Reference: **Maintain-Contact-error-12**
  * Purpose – Demonstrate that the: application displays an error when replacing system/use
  * Input values: Patient has active contact detail. Attempt replace with different system/use.
  * Expected outcome: EM02407 system and use may not be edited.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-13**
  * Purpose – Demonstrate that the: application displays an error when replacing with identical record
  * Input values: Replace contact detail with all fields unchanged.
  * Expected outcome: EM02406 record cannot be replaced with identical record.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-14**
  * Purpose – Demonstrate that the: application displays an error when removing with invalid/inactive contact-id
  * Input values: Remove contact details using inactive, invalid, or non-existent contact-id.
  * Expected outcome: EM07107 contact ID invalid or inactive.
  * Mandatory: Mandatory
* Reference: **Maintain-Contact-error-15**
  * Purpose – Demonstrate that the: API gateway rejects invalid boolean values
  * Input values: Submit non-boolean values for isVerified, isShared or isPrivate.
  * Expected outcome: Request rejected by API gateway.
  * Mandatory: Mandatory

