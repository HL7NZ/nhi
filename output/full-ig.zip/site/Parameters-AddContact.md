# AddContact - New Zealand NHI IG v1.7.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AddContact**

## Example Parameters: AddContact



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "AddContact",
  "parameter" : [{
    "name" : "nhi",
    "valueString" : "ZKC4633"
  },
  {
    "name" : "version-id",
    "valueString" : "12345"
  },
  {
    "name" : "use",
    "valueString" : "home"
  },
  {
    "name" : "system",
    "valueString" : "email"
  },
  {
    "name" : "value",
    "valueString" : "test.contact2@testContact.com"
  },
  {
    "name" : "isVerified",
    "valueBoolean" : true
  },
  {
    "name" : "isShared",
    "valueBoolean" : false
  },
  {
    "name" : "isPrivate",
    "valueBoolean" : true
  },
  {
    "name" : "context",
    "valueString" : "between 9am and 6pm only"
  }]
}

```
