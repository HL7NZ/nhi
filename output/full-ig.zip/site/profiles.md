# Profiles - New Zealand NHI IG v1.6.5

* [**Table of Contents**](toc.md)
* **Profiles**

## Profiles

**Profiles defined in this guide**

* Id: [NhiAddress](StructureDefinition-NhiAddress.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/NhiAddress
  * Description: Adds additional, NHI specific extensions
* Id: [NhiPatient](StructureDefinition-NhiPatient.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/NhiPatient
  * Description: The Patient resource exposed by the NHI.
* Id: [Create Patient](StructureDefinition-CreateNhiPatient.md)
  * Url: hhttp://hl7.org.nz/fhir/StructureDefinition/CreateNhiPatient
  * Description: Create a new Patient resource in the NHI.

