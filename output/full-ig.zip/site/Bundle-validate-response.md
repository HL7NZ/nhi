# validate-response - New Zealand NHI IG v1.6.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **validate-response**

## Example Bundle: validate-response

Bundle validate-response of type searchset

-------

Entry 1

Search:Score = 97

Resource Patient:

> 

version: -1

Profile: [NHI Patient](StructureDefinition-NhiPatient.md)

Anonymous Patient (no stated gender), DoB Unknown ( https://standards.digital.health.nz/ns/nhi-id#NHI#ZJK9604 (use: official, ))
-------



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "validate-response",
  "type" : "searchset",
  "entry" : [
    {
      "resource" : {
        "resourceType" : "Patient",
        "id" : "ZJK9604",
        "meta" : {
          "versionId" : "-1",
          "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NhiPatient"]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_ZJK9604\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient ZJK9604</b></p><a name=\"ZJK9604\"> </a><a name=\"hcZJK9604\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">version: -1</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-NhiPatient.html\">NHI Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Anonymous Patient (no stated gender), DoB Unknown ( https://standards.digital.health.nz/ns/nhi-id#NHI#ZJK9604 (use: official, ))</p><hr/></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "system" : "https://standards.digital.health.nz/ns/nhi-id",
            "value" : "ZJK9604",
            "assigner" : {
              "reference" : "Organization/G00001-G"
            }
          }
        ]
      },
      "search" : {
        "score" : 97
      }
    }
  ]
}

```
