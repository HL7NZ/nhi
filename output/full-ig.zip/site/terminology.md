# Terminology - New Zealand NHI IG v1.7.0

* [**Table of Contents**](toc.md)
* **Terminology**

## Terminology

This page provides a list of the FHIR terminology artifacts defined as part of this implementation guide.

### Code Systems


### ValueSets

| | | |
| :--- | :--- | :--- |
| [NHI ContactPoint System Codes-1.0](ValueSet-nhi-contact-point-system-code-1.0.md) | System values for a ContactPoint supported by the NHI | [https://nzhts.digital.health.nz/fhir/ValueSet/nhi-contact-point-system-code](https://nzhts.digital.health.nz/fhir/ValueSet/nhi-contact-point-system-code) |
| [NHI ContactPoint Use Codes-1.0](ValueSet-nhi-contactpoint-use.md) | Types of contact use supported by the NHI | [https://nzhts.digital.health.nz/fhir/ValueSet/nhiContactUseType](https://nzhts.digital.health.nz/fhir/ValueSet/nhiContactUseType) |

### Concept Maps

|
|

