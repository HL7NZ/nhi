# LastUpdatedDate - New Zealand NHI IG v1.7.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **LastUpdatedDate**

## Extension: LastUpdatedDate 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/lastUpdatedDate | *Version*:1.7.0 |
| Active as of 2026-07-23 | *Computable Name*:LastUpdatedDate |

The date this contact was last updated

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [NHI ContactPoint](StructureDefinition-NhiContactPoint.md)
* Examples for this Extension: [Patient/ZKC4633](Patient-ZKC4633.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.org.nz.fhir.ig.nhi|current/StructureDefinition/StructureDefinition-lastUpdatedDate.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-lastUpdatedDate.csv), [Excel](StructureDefinition-lastUpdatedDate.xlsx), [Schematron](StructureDefinition-lastUpdatedDate.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "lastUpdatedDate",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/lastUpdatedDate",
  "version" : "1.7.0",
  "name" : "LastUpdatedDate",
  "title" : "LastUpdatedDate",
  "status" : "active",
  "date" : "2026-07-23T04:50:58+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "The date this contact was last updated",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Element"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "LastUpdatedDate",
      "definition" : "The date this contact was last updated"
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://hl7.org.nz/fhir/StructureDefinition/lastUpdatedDate"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "date"
      }]
    }]
  }
}

```
