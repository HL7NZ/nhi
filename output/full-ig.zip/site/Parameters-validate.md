# validate - New Zealand NHI IG v1.6.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **validate**

## Example Parameters: validate

## Parameters



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "validate",
  "parameter" : [
    {
      "name" : "resource",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "ZJK9604",
        "identifier" : [
          {
            "use" : "official",
            "system" : "https://standards.digital.health.nz/ns/nhi-id",
            "value" : "ZJK9604",
            "assigner" : {
              "reference" : "Organization/G00001-G"
            }
          }
        ],
        "name" : [
          {
            "family" : "Marblemaw",
            "given" : ["Braylon"]
          }
        ],
        "birthDate" : "1979-06-10",
        "address" : [
          {
            "use" : "home",
            "type" : "physical",
            "line" : ["PO Box 525", "Whanganui 4541"]
          }
        ]
      }
    },
    {
      "name" : "onlyCertainMatches",
      "valueBoolean" : true
    }
  ]
}

```
